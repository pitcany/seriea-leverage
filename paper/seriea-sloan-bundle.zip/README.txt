Beyond Points Accuracy: Survival Forecasts and Fixture Stakes in Serie A
Yannik Pitcan

This manuscript bundle contains the compiled paper, its complete LaTeX
sources, generated tables and figures, and the Sloan abstract.

Read: seriea-leverage-arxiv.pdf
Abstract: SLOAN_ABSTRACT.md
Rebuild: latexmk -pdf seriea-leverage-arxiv.tex
Keep all files together when compiling. A standard LaTeX installation
with the packages declared in the manuscript is required.

Repository: https://github.com/pitcany/seriea-leverage
Revision branch: sloan-scientific-revision
The source code and analytical reports are in the repository.
This ZIP contains manuscript materials, not the raw match dataset.
The manuscript is a draft and includes the author's name.
